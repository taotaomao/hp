var aboutList=[{
    "proName":"张三",
    "proDesc":"产品描述"
},
    {
        "proName":"张三1",
        "proDesc":"产品描述1"
    },
    {
        "proName":"张三2",
        "proDesc":"产品描述2"
    }
]
var newsList =[{
    "newsTitle":"新闻标题1",
    "id":"1"
},
    {
        "newsTitle":"新闻标题2",
        "id":"2"
    },
    {
        "newsTitle":"新闻标题3",
        "id":"3"
    }
]
var newsDetailsList={
    "1":{
        "newsTime":"2017-08-01",
        "newsDesc":"新闻导语1",
        "newsContent":"新闻的内容这是新闻的内容1"

    }, "2":{
        "newsTime":"2017-08-03",
        "newsDesc":"新闻导语2",
        "newsContent":"新闻的内容这是新闻的内容2"

    },"3":{
        "newsTime":"2017-08-05",
        "newsDesc":"新闻导语3",
        "newsContent":"新闻的内容这是新闻的内容3"

    }

}